import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';

import 'rxjs';
import { Observable } from 'rxjs/Observable';
import { Post } from '../_entity/post';

// import { Observable } from 'rxjs/Observable';
// import { Post } from '../_entity/post';
// import { of } from 'rxjs/observable/of';
// import { POSTS } from './mock/mock-posts';
// import { User } from '../_entity/user';

@Injectable()
export class PostService {
  private basuUrl = 'https://trocajogo-3092b.firebaseio.com';
  private posts = [];
  constructor(private http: Http) {
  }

  getPosts(): Observable<any> {
    return this.http.get(`${this.basuUrl}/posts.json`)
      .map((response: Response) => {
        console.log('getPosts()');
        let postsAux = response.json();
        postsAux.forEach(element => {
          
          this.posts.push(Object.assign(Post, element));
        });
        console.log('POSTS');
        console.log(this.posts);
        return this.posts;
      })

  }

  insertNewPost() {
  }

}
