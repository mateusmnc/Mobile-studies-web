import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { PostService } from '../../_service/post.service';

@Component({
  selector: 'page-postar-jogo',
  templateUrl: 'postar-jogo.html'
})
export class PostarJogoPage {
  // this tells the tabs component which Pages
  // should be each tab's root Page
  post = {};
  constructor(
    public navCtrl: NavController,
    private navParams: NavParams){
      
    }
}
