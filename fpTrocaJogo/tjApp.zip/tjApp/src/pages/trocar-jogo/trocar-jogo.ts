import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { PostService } from '../../_service/post.service';
import { Post } from '../../_entity/post';

@Component({
  selector: 'page-trocar-jogo',
  templateUrl: 'trocar-jogo.html'
})

export class TrocarJogoPage {
  // this tells the tabs component which Pages
  // should be each tab's root Page
  posts:Array<Post>;
  constructor(public navCtrl: NavController,
              private postService: PostService) {
    this.carregarPost();
    
  }

  carregarPost(){
    console.log('carregapost chamado');
    this.postService.getPosts().subscribe(postsFromDB => {
      this.posts = postsFromDB;
    });    
  } 

  ionViewWillEnter(){
    console.log('ionViewWillEnter chamado');
    this.carregarPost();
  }
}
