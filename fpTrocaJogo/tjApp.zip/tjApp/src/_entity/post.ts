export class Post {
    public game: string;
    public local: string;
    public plataform: string;

    constructor(game, local, plataform ) {
        this.game = game; 
        this.local = local;
        this.plataform = plataform;
        
    }
}
